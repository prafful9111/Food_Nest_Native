// constants/auth.ts
export const SUPERADMIN_CREDENTIALS = {
  email: "superadmin@foodnest.app",
  password: "SuperSecret123!",
  role: "superadmin" as const,
};
