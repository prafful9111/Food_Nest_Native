import { Stack } from "expo-router";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { View } from "react-native";
import { Slot } from "expo-router";

export default function RootLayout() {
return <Slot />;
}
